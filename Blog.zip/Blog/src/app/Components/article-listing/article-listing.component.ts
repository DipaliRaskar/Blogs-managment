import { Component } from '@angular/core';
import { ArticleService } from '../../services/article.service';

@Component({
  selector: 'app-article-listing',
  templateUrl: './article-listing.component.html',
  styleUrl: './article-listing.component.css'
})
export class ArticleListingComponent {
articleMessage:undefined|String;
  users:any

  constructor(private artical:ArticleService){

    this.articleList();
    // artical.articles().subscribe((data)=>{
    //   console.log("data",data)
    //   this.users=data
    // });
   
  }

  deleteProduct(id:number){
    console.log("test id",id)
    this.artical.deleteProduct(id).subscribe((res)=>{
      if(res){
        this.articleMessage="Article is deleted";
        this.articleList()
      }

    })
    setTimeout(() => {
      this.articleMessage=undefined
    }, 3000);
  }
  articleList(){


      //get method calling is hare
    this.artical.articles().subscribe((data)=>{
      console.log("data",data)
      this.users=data
    });


    
   
  }
    
}


