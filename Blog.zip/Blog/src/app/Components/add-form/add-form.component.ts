import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ArticleService } from '../../services/article.service';
ArticleService


@Component({
  selector: 'app-add-form',
  templateUrl: './add-form.component.html',
  styleUrl: './add-form.component.css'
})
export class AddFormComponent {

  toggle:boolean = true
 
formatText(arg0: string) {
throw new Error('Method not implemented.');
}

 
  onSubmit() {
    if (this.articleForm.valid) {
      console.log(this.articleForm.value);
      this.articleService.SaveData(this.articleForm.value).subscribe(res=>{
        console.log(res);
      })
    }
  }

  articleForm: FormGroup;
  articles: any[] = [];

  constructor(private fb: FormBuilder, private articleService: ArticleService) {
    // Initialize the form with validation rules
    this.articleForm = this.fb.group({
      title: ['', [Validators.required, Validators.pattern('^[A-Za-z]+$')]],
      developedBy: ['', [Validators.required, Validators.pattern('^[A-Za-z]+$')]],
      description: ['', Validators.required],
      picture: ['', Validators.required],

      rate: ['', [Validators.required, Validators.min(1), Validators.max(5)]],
      articleDate: ['', [Validators.required, Validators.pattern('^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[0-2])/([2-9][0-9]{3})$')]]
    });
  }


}
