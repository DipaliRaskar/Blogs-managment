import { Component ,OnInit} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ArticleService } from '../../services/article.service';

@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrl: './view-details.component.css'
})
export class ViewDetailsComponent implements OnInit {
  constructor(private route:ActivatedRoute,private Article:ArticleService){}

  id:any='';
Data:any;
Name:any;
Comments:any;


  ngOnInit(): void {
    this.id = this.route.snapshot.paramMap.get('id');
    console.log(this.id);
   
    this.Article.getarticle(this.id).subscribe(res =>{
      console.log(res);
      this.Data = res;
      
    })

    this.Article.GetComment(this.id).subscribe((res:any) =>{
      // console.log("res",res.Comment)
   
      this.Comments=res.Comment;
      console.log(this.Comments)

    })
  }

}
