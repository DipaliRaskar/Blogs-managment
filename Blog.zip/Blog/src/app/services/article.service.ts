import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ArticleService {


url = "http://localhost:3000/articles";

url2 = "http://localhost:3000/comments";


//get method.

constructor(private http:HttpClient) { }
articles(){
  return this.http.get(this.url)
}

getarticle(id:any){
  return this.http.get(this.url+"/"+id);
}

//post method

SaveData(data:any){
  return this.http.post(this.url,data);
}


//delete method
deleteProduct(id:number){
 return this.http.delete(`http://localhost:3000/articles/${id}`);

}


GetComment(id:any)
{
  return this.http.get(this.url+"/"+id);
}


CommentPost(id:any,commentsData:any){
  return this.http.put(this.url+"/"+id,commentsData);
  
}
}


