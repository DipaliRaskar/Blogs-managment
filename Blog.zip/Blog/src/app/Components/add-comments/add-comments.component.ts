import { Component, OnInit } from '@angular/core';
import { ArticleService } from '../../services/article.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-add-comments',
  templateUrl: './add-comments.component.html',
  styleUrl: './add-comments.component.css',
})
export class AddCommentsComponent implements OnInit {
  constructor(private http: ArticleService, private route: ActivatedRoute) {}
  id: any;
  name: any = [];
  comment: any = [];
  t1: any;

  temp_name: any = '';
  temp_Comment = '';
  Data: any;

  ngOnInit(): void {
    this.id = this.route.snapshot.paramMap.get('id');

    this.http.GetComment(this.id).subscribe((res: any) => {
      console.log(res);
      this.t1 = res;

      this.comment = res.Comment;
    });
  }

  onSubmit() {
    this.comment.push({ Name: this.temp_name, Comment: this.temp_Comment });

    this.Data = {
      id: this.t1.id,
      title: this.t1.title,
      developedBy: this.t1.developedBy,
      description: this.t1.description,
      picture: this.t1.picture,
      rate: this.t1.rate,
      articleDate: this.t1.articleDate,
      Comment: this.comment,
    };

    this.http.CommentPost(this.id, this.Data).subscribe((res) => {
      console.log(res);
    });
  }
}
