import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ArticleListingComponent } from './Components/article-listing/article-listing.component';
import { AddCommentsComponent } from './Components/add-comments/add-comments.component';
import { AddFormComponent } from './Components/add-form/add-form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HomePageComponent } from './Components/home-page/home-page.component';
import { ViewDetailsComponent } from './Components/view-details/view-details.component';

@NgModule({
  declarations: [
    AppComponent,
    ArticleListingComponent,
    AddCommentsComponent,
    AddFormComponent,
    HomePageComponent,
    ViewDetailsComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
