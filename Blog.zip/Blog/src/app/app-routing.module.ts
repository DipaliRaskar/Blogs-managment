import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddCommentsComponent } from './Components/add-comments/add-comments.component';
import { ArticleListingComponent } from './Components/article-listing/article-listing.component';
import { AddFormComponent } from './Components/add-form/add-form.component';
import { HomePageComponent } from './Components/home-page/home-page.component';
import { ViewDetailsComponent } from './Components/view-details/view-details.component';

const routes: Routes = [
  {path: 'Article', component:ArticleListingComponent},
  {path: 'comment', component:AddCommentsComponent},
  {path:"AddArticle",component:AddFormComponent},
  {path:"Home",component:HomePageComponent},
  {path:"ViewDetails",component:ViewDetailsComponent},
  {
    path:"",pathMatch:"full",redirectTo:"/Home"
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
